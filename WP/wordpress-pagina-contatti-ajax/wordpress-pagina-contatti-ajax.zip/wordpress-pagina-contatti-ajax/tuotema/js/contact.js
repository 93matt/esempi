(function($) {


	$(function() {
	
		var Contact = function() {
		
			var form = '#contact';
			
			
			
			
			this.process = function() {
			
			
			$(form).submit(function(event) {
			
				var $form = $(this);
				var url = $form.attr('action');
				var data = 'from=' + $('#from', $form).val() + '&email=' + $('#email', $form).val() +
				            '&subject=' + $('#subject', $form).val() +
				            '&message=' + $('#message', $form).val() +
				            '&captcha=' + $('#captcha', $form).val() +
				            '&contact-submit=Send&ajax=true';
				
				$.ajax({
					type: 'POST',
					dataType: 'text',
					url: url,
					data: data,
					success: function(txt) {
					
					    $('div.success, div.error', $form).remove();
					
						$(txt).prependTo($('ul', $form));
						
						$('html, body').animate({
							scrollTop: $form.offset().top
						}, 500);
						
					
					
					}
					
				});
				
				
				event.preventDefault();
			
			
			});
			
			}
		
		
		};
		
		var contact = new Contact();
		
		if($('#contact').length) {
		
			contact.process();
			
		}
	
	
	});


})(jQuery);