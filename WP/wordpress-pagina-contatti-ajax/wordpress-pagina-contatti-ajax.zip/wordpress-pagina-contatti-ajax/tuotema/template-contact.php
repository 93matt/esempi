<?php
/*
Template Name: Contact Form
*/
?>

<?php
require_once('inc/contact/Contact.php');

$contact = new Contact();

if(isset($_POST['ajax'])) {

	echo $contact->process();
	
	exit();
	
} else {

?>

<?php get_header(); ?>


<div id="content">

<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>

<h1><?php the_title(); ?></h1>

<?php the_content(); ?>

<form action="<?php the_permalink();?>" method="post" id="contact">
	
	<ul>
	
		<li><label for="from">Name</label>
			<input type="text" name="from" id="from" />
		</li>
		
		<li><label for="email">E-mail</label>
			<input type="text" name="email" id="email" />
		</li>
		
		<li><label for="subject">Subject</label>
			<input type="text" name="subject" id="subject" />
		</li>
		
		<li>
			<label for="message">Message</label>
			<textarea id="message" name="message" id="message"></textarea>
		</li>
		
		<li><label for="captcha">6 + 5 ?</label>
			<input type="text" name="captcha" id="captcha" />
		</li>

	
	</ul>
	
	<p><input type="submit" name="contact-submit" id="contact-submit" value="Send" /></p>

</form>



<?php endwhile; ?>
</div>

</div>       
            
 
 


<?php get_sidebar(); ?>


<?php get_footer(); ?>

<?php } ?>