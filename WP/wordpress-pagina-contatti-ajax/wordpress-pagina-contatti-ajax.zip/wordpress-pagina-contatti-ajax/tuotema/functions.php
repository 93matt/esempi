<?php

/* Codice da aggiungere al file functions.php del tema.
 * Se jQuery è già stata inclusa dal tema, non è necessario
 * utilizzare wp_enqueue_script('jquery')
 */

function add_scripts() {

	if(!is_admin()) {

	wp_enqueue_script('jquery');
	wp_register_script('contact', get_bloginfo('template_url') . '/js/contact.js', '1.0', true);
	wp_enqueue_script('contact');
	
	
	}
}

add_action('wp_footer', 'add_scripts');

?>