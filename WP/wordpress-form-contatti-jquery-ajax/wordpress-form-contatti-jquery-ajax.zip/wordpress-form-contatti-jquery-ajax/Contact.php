<?php
class Contact
{
	const TO = 'tua email';
	protected $_from;
	protected $_subject;
	protected $_message;
	protected $_email;
	protected $_captcha;
	
	public function __construct()
	{
	
		$this->_from = $_POST['from'];
		$this->_subject = $_POST['subject'];
		$this->_email = $_POST['email'];
		$this->_message = $_POST['message'];
		$this->_captcha = $_POST['captcha'];
	
	
	}
	
	private function _validate() 
	{
	
		$errors = '';
		
		if(empty($this->_from)) {
		
			$errors .= '<div class="error">Nome mancante</div>';
		
		}
		
		if(empty($this->_subject)) {
		
			$errors .= '<div class="error">Manca l\'oggetto</div>';
		
		}
		
		if(!filter_var($this->_email, FILTER_VALIDATE_EMAIL)) {
		
			$errors .= '<div class="error">E-mail non valida</div>';
		
		}
		
		if(empty($this->_message)) {
		
			$errors .= '<div class="error">Manca il messaggio</div>';
		
		}
		
		if(!preg_match('/^11$/', $this->_captcha)) {
		
			$errors .= '<div class="error">Risposta errata</div>';
		
		}
		
		return $errors;
	
	
	}
	
	private function _send()
	{
	
		$headers = 'From: ' .' <'.$this->_email.'> ' . "\r\n";
		$message = $this->_from . ' ha scritto in data ' . strftime('%d-%m-%Y %H:%M:%S', time()) . ': ' . "\n\n";
		$message .= $this->_message;
		
		@mail(self::TO, $this->_subject, $message, $headers); 
	
	}
	
	
	public function process()
	{
	
		$message = '';
		
	  if(isset($_POST['contact-submit'])) {
		
		$validation = $this->_validate();
		
		if($validation != '') {
		
			$message = $validation;
		
		} else {
		
			$this->_send();
			
			$message = '<div class="success">E-mail inviata con successo</div>';
		
		}
		
	   }
	
		return $message;
	}
	
	


}