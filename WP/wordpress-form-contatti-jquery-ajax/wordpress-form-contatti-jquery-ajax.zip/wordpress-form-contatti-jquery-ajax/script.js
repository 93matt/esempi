(function($) {


	$(function() {
	
		var Contact = function() {
		
			var form = '#contact';
			
			
			
			
			this.process = function() {
			
			
			$(form).submit(function(event) {
			
				var $form = $(this);
				var url = $form.attr('action');
				var data = 'from=' + $('#from', $form).val() + '&email=' + $('#email', $form).val() +
				            '&subject=' + $('#subject', $form).val() +
				            '&message=' + $('#message', $form).val() +
				            '&captcha=' + $('#captcha', $form).val() +
				            '&contact-submit=Invia';
				
				$.ajax({
					type: 'POST',
					dataType: 'html',
					url: url,
					data: data,
					success: function(html) {
					
					    $('div.success, div.error', $form).remove();
					
						$(html).prependTo($('ul', $form));
						
					
					
					}
					
				});
				
				
				event.preventDefault();
			
			
			});
			
			}
		
		
		};
		
		var contact = new Contact();
		contact.process();
	
	
	});


})(jQuery);