<?php
header('Content-Type: text/html');
require_once('Contact.php');

$contact = new Contact();

echo $contact->process();
?>
