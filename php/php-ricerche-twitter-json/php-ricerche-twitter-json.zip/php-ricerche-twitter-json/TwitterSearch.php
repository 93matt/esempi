<?php
class TwitterSearch
{

	const URL = 'http://search.twitter.com/search.json?q=';
	public $term;
	
	public function __construct($term)
	{
	
		$this->term = $term;
	
	}
	
	private function _niceTime($time) 
	{
  		$delta = time() - strtotime($time);
  		
  		if ($delta < 60) {
    		return 'meno di 1 minuto fa.';
  		} else if ($delta < 120) {
    		return 'circa 1 minuto fa.';
  		} else if ($delta < (45 * 60)) {
    		return floor($delta / 60) . ' minuti fa.';
  		} else if ($delta < (90 * 60)) {
    		return 'circa 1 ora fa.';
  		} else if ($delta < (24 * 60 * 60)) {
    		return 'circa ' . floor($delta / 3600) . ' ore fa.';
  		} else if ($delta < (48 * 60 * 60)) {
    		return '1 giorno fa.';
  		} else {
    		return floor($delta / 86400) . ' giorni fa.';
  		}
	}
	
	private function _formatURLs($text)
	{
	
		return preg_replace('/http:\/\/(.*?)\/[^ ]*/', '<a href="\\0">\\0</a>', $text);
	
	}

	
	private function _fetch() 
	{
	
		$jsonString = @file_get_contents(self::URL . urlencode($this->term));
		
		if(!$jsonString) {
		
			return null;
		
		}
		
		return $jsonString;
	
	}
	
	private function _parse()
	{
	
		$json = $this->_fetch();
		
		if(is_null($json)) {
		
			return null;
		
		}
		
		return json_decode($json, true);
	
	}
	
	public function render()
	{
	
		$output = $this->_parse();
		$results = $output['results'];
		$html = '';
		
		if(is_null($output)) {
		
			return '<p>Ricerca fallita.</p>';
		
		}
		
		foreach($results as $result) {
		
			$profileImage = $result['profile_image_url'];
			$from = $result['from_user'];
			$id = $result['id_str'];
			$text = $this->_formatURLs($result['text']);
			$time = $this->_niceTime($result['created_at']);
			
			$html .= '<div class="tweet">' . "\n";
			$html .= '<div class="profile">' . "\n";
			$html .= '<img src="' . $profileImage . '" alt="" />' . "\n";
			$html .= '<a href="http://www.twitter.com/' . $from . '/status/' . $id . '">' .
					  $from . '</a>' . "\n";
			$html .= '</div>' . "\n";
			$html .= '<p>' . $text . '</p>' . "\n";
			$html .= '<div class="time">' . $time . '</div>' . "\n";
			$html .= '</div>';
		
		
		}
		
		return $html;
	
	}
	


}

