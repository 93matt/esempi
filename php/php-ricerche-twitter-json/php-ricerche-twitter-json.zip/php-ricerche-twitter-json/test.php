<?php
require_once('TwitterSearch.php');
$twitterSearch = new TwitterSearch('gabriele romanato');
?>
<!DOCTYPE html>
<html>
<head>
<title>PHP: ricerche su Twitter con JSON</title>
<meta charset="utf-8" />
<style type="text/css" media="screen">
html {
	background: #f0f0f0;
}

body {
	margin: 2em auto;
	width: 50%;
	max-width: 400px;
	padding: 1em;
	background: #fff;
	color: #333;
	font: 300 95% 'Helvetica Neue', Arial, sans-serif;
}

a {
	color: #000;
	text-decoration: none;
}

a:hover {
	color: #444;
	text-decoration: underline;
}

h2, p {
	margin: 0;
	font-size: 100%;
	font-weight: normal;
}

#twitter-search h2 {
	text-align: center;
	font-size: 1.8em;
}

div.tweet {
	margin-bottom: 1em;
}

div.profile {
	overflow: hidden;
	padding-bottom: 0.5em;
	padding-top: 0.5em;
	height: 3em;
	position: relative;
}

div.profile img {
	position: absolute;
	bottom: 0;
	left: 0;
}

div.profile a {
	position: absolute;
	bottom: 0;
	left: 3em;
	text-transform: uppercase;
	font-size: 1.4em;
}

div.tweet div.time {

	margin-top: 0.5em;
	font-style: italic;
	border-bottom: 1px solid #aaa;
	padding-bottom: 0.2em;

}

</style>
</head>

<body>

<div id="twitter-search">

<h2>Su Gabriele Romanato</h2>

<?php echo $twitterSearch->render(); ?>

</div>

</body>
</html>