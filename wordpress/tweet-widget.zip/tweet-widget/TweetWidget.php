<?php
/*
Plugin Name: Tweet Widget
Plugin URI: http://gabrieleromanato.com
Description: Displays your latest tweets
Author: Gabriele Romanato
Version: 1
Author URI: http://gabrieleromanato.com/
*/
 
require_once('TwitterWidget.php');
 
class TweetWidget extends WP_Widget
{
  function TweetWidget()
  {
    $widget_ops = array('classname' => 'TweetWidget', 'description' => 'Displays your latest tweets' );
    $this->WP_Widget('TweetWidget', 'Tweet Widget', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'tweets' => 5, 'username' => 'gabromanato' ) );
    $title = $instance['title'];
    $tweets = $instance['tweets'];
    $username = $instance['username'];
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label>
  <label for="<?php echo $this->get_field_id('tweets');?>">Tweets: <input class="widefat" id="<?php echo $this->get_field_id('tweets'); ?>" name="<?php echo $this->get_field_name('tweets'); ?>" type="text" value="<?php echo attribute_escape($tweets); ?>" /></label>
  <label for="<?php echo $this->get_field_id('username');?>">Username: <input class="widefat" id="<?php echo $this->get_field_id('username'); ?>" name="<?php echo $this->get_field_name('username'); ?>" type="text" value="<?php echo attribute_escape($username); ?>" /></label>
  </p>
<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    $instance['tweets'] = $new_instance['tweets'];
    $instance['username'] = $new_instance['username'];
    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
    $tweets = (!empty($instance['tweets'])) ? intval($instance['tweets']) : 5;
    $username = (!empty($instance['username'])) ? $instance['username'] : 'gabromanato';
 
    if (!empty($title))
      echo $before_title . $title . $after_title;;


	$tweetWidget = new TwitterWidget($username, $tweets); 
	
	echo $tweetWidget->outputWidget();
 
    echo $after_widget;
  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("TweetWidget");') );?>