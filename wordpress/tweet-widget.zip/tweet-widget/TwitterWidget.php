<?php
class TwitterWidget
{

  protected $_username;
  protected $_limit;
  
  public function __construct($username, $limit)
  {
  
    $this->_username = $username;
    $this->_limit = $limit;
  
  }
  
  /** @param String $text Il testo del tweet
      @returns String $replaced Una stringa con gli URL trasformati in elementi <a> */
  
  protected function _replaceTextURLs($text)
  {
  
    $re = '/(http:\/\/[^\s&]+)/';
	
	$replaced = preg_replace($re, '<a href="$1">$1</a>', $text);
	
	return $replaced;
  
  
  }
  
  /** @param String $time Un timestamp Unix
      @returns String Il tempo trascorso dall'ultimo tweet */
  
  protected function _niceTime($time) 
  {
  	$delta = time() - $time;
  	if ($delta < 60) {
    	return 'meno di un minuto fa.';
  	} else if ($delta < 120) {
    	return 'circa un minuto fa.';
  	} else if ($delta < (45 * 60)) {
    	return floor($delta / 60) . ' minuti fa.';
 	} else if ($delta < (90 * 60)) {
    	return 'circa un\'ora fa.';
  	} else if ($delta < (24 * 60 * 60)) {
    	return 'circa ' . floor($delta / 3600) . ' ore fa.';
  	} else if ($delta < (48 * 60 * 60)) {
    	return '1 giorno fa.';
  	} else {
    	return floor($delta / 86400) . ' giorni fa.';
  	}
  }
  
  
  /** @param Nessuno
      @returns La seguente stringa HTML
      <div class="twitter-widget">
        <div class="tweet">
          <p>Il tweet</p>
          <div class="tweet-time-ago">Il tempo trascorso</div>
          <!--more tweets-->
        </div>
      </div> */
  
    
  public function outputWidget()
  {
  
    $tweets = simplexml_load_file('http://twitter.com/statuses/user_timeline/'. $this->_username . '.rss');

    if($tweets) {
	
	$output = '<div class="twitter-widget">' . "\n";
		
	$i = -1;
	
	$tweetNo = $this->_limit - 1;
	
	do {
	
	  $i++;
	
	  $tweet = $tweets->channel->item[$i];
	  $text = str_replace($this->_username . ':', '', $tweet->title);
	  $text = $this->_replaceTextURLs($text);
	  $time = strtotime(str_replace('+0000', '', $tweet->pubDate));
	
	  $output .= '<div class="tweet">' . "\n". '<div>' . $text . '</div>' . "\n" .
	               '<div class="tweet-time-ago">' . $this->_niceTime($time) . '</div>' . "\n" . '</div>' . "\n";
	
	} while($i < $tweetNo);
	
	$output .= '</div>' . "\n";

      } else {

         $output = '<div class="twitter-widget-error">I tweet non sono disponibili.</div>';

      }
	
	return $output;
  
  
  }


}
?>
