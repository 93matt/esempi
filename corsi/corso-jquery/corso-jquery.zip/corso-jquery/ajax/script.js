var test = function() {
	alert('OK');
};